import assert from "node:assert/strict";
import test from "node:test";
import { loadEnvironment } from "../src/config/env";

test("development defaults are safe and database configuration is optional", () => {
  const config = loadEnvironment({});

  assert.equal(config.nodeEnv, "development");
  assert.equal(config.port, 5000);
  assert.deepEqual(config.clientOrigins, ["http://localhost:5173"]);
  assert.equal(config.databaseUrl, undefined);
});

test("configured client origins are normalized and deduplicated", () => {
  const config = loadEnvironment({
    CLIENT_URL: "https://aiaiac.example, https://aiaiac.example, http://localhost:5173",
  });

  assert.deepEqual(config.clientOrigins, ["https://aiaiac.example", "http://localhost:5173"]);
});

test("production requires an explicit client origin", () => {
  assert.throws(
    () => loadEnvironment({ NODE_ENV: "production" }),
    /CLIENT_URL is required in production/,
  );
});

test("wildcard CORS and invalid database protocols fail without echoing values", () => {
  assert.throws(() => loadEnvironment({ CLIENT_URL: "*" }), /CLIENT_URL/);

  const secretValue = "mysql://user:secret@example.invalid/database";
  assert.throws(
    () => loadEnvironment({ DATABASE_URL: secretValue }),
    (error: unknown) => error instanceof Error && !error.message.includes(secretValue),
  );
});
