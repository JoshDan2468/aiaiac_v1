import assert from "node:assert/strict";
import test from "node:test";
import express from "express";
import request from "supertest";
import { app } from "../src/app";
import { errorHandler } from "../src/middleware/error.middleware";

test("GET /api/health returns the public health payload", async () => {
  const response = await request(app).get("/api/health").expect(200).expect("Content-Type", /json/);

  assert.equal(response.body.success, true);
  assert.equal(response.body.message, "AIAIAC API is running");
  assert.equal(response.body.environment, "development");
  assert.match(response.body.timestamp, /^\d{4}-\d{2}-\d{2}T/);
  assert.equal(response.headers["cache-control"], "no-store");
  assert.equal(response.headers["x-powered-by"], undefined);
  assert.equal(response.headers["x-content-type-options"], "nosniff");
});

test("unknown API routes return predictable JSON", async () => {
  const response = await request(app).get("/api/does-not-exist").expect(404);

  assert.deepEqual(response.body, {
    success: false,
    message: "API route not found",
  });
});

test("CORS permits the configured frontend origin", async () => {
  const response = await request(app)
    .get("/api/health")
    .set("Origin", "http://localhost:5173")
    .expect(200);

  assert.equal(response.headers["access-control-allow-origin"], "http://localhost:5173");
});

test("CORS rejects unconfigured browser origins", async () => {
  const response = await request(app)
    .get("/api/health")
    .set("Origin", "https://untrusted.example")
    .expect(403);

  assert.deepEqual(response.body, {
    success: false,
    message: "Origin not allowed",
  });
});

test("malformed JSON uses the central error response", async () => {
  const response = await request(app)
    .post("/api/health")
    .set("Content-Type", "application/json")
    .send('{"broken"')
    .expect(400);

  assert.deepEqual(response.body, {
    success: false,
    message: "Invalid JSON request body",
  });
  assert.equal(JSON.stringify(response.body).includes("stack"), false);
});

test("unexpected errors are sanitized", async () => {
  const testApp = express();
  testApp.get("/boom", () => {
    throw new Error("sensitive internal detail");
  });
  testApp.use(errorHandler);

  const response = await request(testApp).get("/boom").expect(500);

  assert.deepEqual(response.body, {
    success: false,
    message: "Internal server error",
  });
  assert.equal(JSON.stringify(response.body).includes("sensitive internal detail"), false);
});
