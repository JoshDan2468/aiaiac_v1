# AIAIAC API foundation

This package is the initial Express and TypeScript backend for AIAIAC West Africa. Its current
scope is deliberately small: secure application setup, validated environment configuration, an
optional PostgreSQL pool configuration, and one public health endpoint.

## Setup

```sh
npm install
copy .env.example .env
npm run dev
```

On macOS or Linux, replace `copy` with `cp`.

The development server defaults to `http://localhost:5000`. The health endpoint is:

```http
GET /api/health
```

## Environment variables

| Variable       | Required   | Purpose                                                           |
| -------------- | ---------- | ----------------------------------------------------------------- |
| `NODE_ENV`     | No         | `development`, `test`, or `production`; defaults to `development` |
| `PORT`         | No         | HTTP port; defaults to `5000`                                     |
| `CLIENT_URL`   | Production | Comma-separated allowed frontend origins                          |
| `DATABASE_URL` | No         | PostgreSQL URL; blank is valid during this foundation phase       |

`CLIENT_URL` never accepts `*`. Requests without an `Origin` header remain available to Postman,
curl, and infrastructure health probes. If `DATABASE_URL` is absent, the API starts normally and
does not pretend that persistence exists. If it is supplied, a bounded `pg` pool is prepared
lazily; this phase does not run queries, create tables, or perform migrations.

## Commands

```sh
npm run dev
npm run type-check
npm test
npm run build
npm start
```

The application uses Helmet security headers, a `100kb` request-body limit, origin-restricted
CORS, development request logging that excludes bodies and query strings, predictable JSON 404
and error responses, and graceful HTTP/database-pool shutdown.

This is a security foundation, not a complete security guarantee. Authentication, authorization,
rate limiting, database migrations, admin APIs, participation workflows, Paystack, and business
logic remain unimplemented.
