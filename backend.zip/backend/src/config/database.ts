import { Pool } from "pg";
import { env } from "./env";

let pool: Pool | null = null;

export function getDatabasePool(): Pool | null {
  if (!env.databaseUrl) return null;

  pool ??= new Pool({
    connectionString: env.databaseUrl,
    max: 10,
    connectionTimeoutMillis: 5_000,
    idleTimeoutMillis: 30_000,
  });

  return pool;
}

export async function closeDatabasePool(): Promise<void> {
  if (!pool) return;
  await pool.end();
  pool = null;
}
