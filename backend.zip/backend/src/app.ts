import cors from "cors";
import express from "express";
import helmet from "helmet";
import { env } from "./config/env";
import { createPublicError, errorHandler } from "./middleware/error.middleware";
import { notFoundHandler } from "./middleware/notFound.middleware";
import { requestLogger } from "./middleware/requestLogger.middleware";
import { apiRouter } from "./routes";

export const app = express();

app.disable("x-powered-by");
app.set("json escape", true);

app.use(requestLogger);
app.use(helmet());
app.use(
  cors({
    origin(origin, callback) {
      if (!origin || env.clientOrigins.includes(origin)) {
        callback(null, true);
        return;
      }

      callback(createPublicError(403, "Origin not allowed"));
    },
    credentials: false,
    methods: ["GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
  }),
);
app.use(express.json({ limit: "100kb" }));
app.use(express.urlencoded({ extended: false, limit: "100kb" }));

app.use("/api", apiRouter);
app.use(notFoundHandler);
app.use(errorHandler);
